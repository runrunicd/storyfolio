// Product screen mockups for Storyfolio
// Reusable components for rendering redesigned app views inside the landing page.

// ─── Scene library: hand-drawn storyboard sketches ────────
// Looks like quick ink-on-paper storyboard frames: wavy borders, scribbled
// figures, horizontal scribbles standing in for unwritten manuscript, panel
// numbers in cursive, and an optional yellow highlighter "light pass" on
// the frame being actively worked.
const PencilDefs = () => (
  <svg width="0" height="0" style={{ position: 'absolute' }} aria-hidden="true">
    <defs>
      <filter id="pencilWobble" x="-5%" y="-5%" width="110%" height="110%">
        <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="1" seed="4" />
        <feDisplacementMap in="SourceGraphic" scale="0.6" />
      </filter>
      <filter id="inkWobble" x="-5%" y="-5%" width="110%" height="110%">
        <feTurbulence type="fractalNoise" baseFrequency="1.4" numOctaves="1" seed="9" />
        <feDisplacementMap in="SourceGraphic" scale="1.1" />
      </filter>
    </defs>
  </svg>
);

const Scene = ({ name, dark = false, panelNum, highlight, worked = false }) => {
  // Ink on paper. Worked frames get darker lines + hatching; unworked are looser.
  const ink = 'rgba(32,28,24,0.88)';
  const inkMid = 'rgba(32,28,24,0.6)';
  const inkLight = 'rgba(32,28,24,0.3)';
  const yellow = 'rgba(246,214,80,0.55)';

  const pen = {
    stroke: ink, strokeWidth: worked ? 1.1 : 1.3, fill: 'none',
    strokeLinecap: 'round', strokeLinejoin: 'round',
    filter: 'url(#inkWobble)',
  };
  const penMid = { ...pen, stroke: inkMid, strokeWidth: 0.8 };
  const penLight = { ...pen, stroke: inkLight, strokeWidth: 0.6 };
  const hatchLine = { stroke: ink, strokeWidth: 0.5, fill: 'none', filter: 'url(#pencilWobble)' };

  // Wavy scribble — a quick undulating line for "text lines" or horizons.
  const scribbleLine = (x1, y, x2, amp = 0.6, seg = 8) => {
    let d = `M ${x1} ${y}`;
    const n = Math.ceil((x2 - x1) / seg);
    for (let i = 1; i <= n; i++) {
      const sx = x1 + (i * (x2 - x1)) / n;
      const cx = x1 + ((i - 0.5) * (x2 - x1)) / n;
      const cy = y + (i % 2 === 0 ? -amp : amp);
      d += ` Q ${cx} ${cy} ${sx} ${y}`;
    }
    return d;
  };

  // "Manuscript lines" — horizontal scribbles like sample image 2.
  const ScribbleText = ({ x, y, width, lines = 3, gap = 5 }) => (
    <g {...penMid}>
      {Array.from({ length: lines }).map((_, i) => (
        <path key={i} d={scribbleLine(x, y + i * gap, x + width, 0.7, 6)} />
      ))}
    </g>
  );

  const scenes = {
    dusk: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        {highlight && (
          <path d="M 118 92 L 160 58 L 180 58 L 160 102 L 128 128 L 100 128 Z"
                fill={yellow} opacity="0.55" filter="url(#inkWobble)" />
        )}
        <path d={scribbleLine(6, 92, 194, 0.8, 10)} {...pen} />
        <path d="M 12 92 Q 34 78 58 88 Q 76 94 92 92" {...pen} />
        <path d="M 102 93 Q 128 80 150 90 T 190 92" {...pen} />
        <g {...pen}>
          <circle cx="150" cy="82" r="10" />
          <circle cx="150" cy="82" r="10.6" opacity="0.5" />
          <line x1="150" y1="66" x2="150" y2="70" />
          <line x1="166" y1="82" x2="170" y2="82" />
          <line x1="134" y1="82" x2="130" y2="82" />
        </g>
        {worked && (
          <g {...hatchLine}>
            {[102,106,110,114,118,122,126].map((y,i) => (
              <path key={i} d={scribbleLine(6, y, 194, 0.5, 14)} opacity={0.35 - i*0.03} />
            ))}
          </g>
        )}
        <g {...pen} transform="translate(40,70)">
          <circle cx="6" cy="4" r="3" />
          <path d="M 2 7 Q 6 10 10 7 Q 12 12 11 22 Q 6 24 1 22 Q 0 12 2 7 Z" />
          <line x1="3" y1="22" x2="2.5" y2="30" />
          <line x1="9" y1="22" x2="9.5" y2="30" />
          <circle cx="18" cy="10" r="2.3" />
          <path d="M 15.5 12 Q 18 14 20.5 12 Q 21.5 16 21 22 Q 18 23 15 22 Q 14.5 16 15.5 12 Z" />
          <line x1="16.5" y1="22" x2="16" y2="28" />
          <line x1="19.5" y1="22" x2="20" y2="28" />
          <path d="M 11 16 Q 13 17 15 16" />
        </g>
        <text x="8" y="132" fontFamily="Caveat, cursive" fontSize="9" fill={inkMid}>the quiet hour</text>
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    forest: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g {...pen}>
          <path d="M 148 22 q 6 -6 14 -2 q 8 6 2 14 q -4 8 -12 4 q -8 -6 -4 -16 z" />
        </g>
        {[24, 54, 88, 124, 162].map((x, i) => (
          <g key={i} {...pen}>
            <path d={`M ${x} 16 q -1 30 0 60 q 1 30 ${(i%2)?0.5:-0.5} 64`} />
            <path d={`M ${x+3+(i%3)} 16 q 1 30 0 60 q -1 30 ${(i%2)?-0.5:0.5} 64`} />
          </g>
        ))}
        <g {...penMid}>
          <path d="M 14 22 q -4 -8 4 -12 q 6 -6 14 -2 q 8 -4 14 4 q 6 6 0 14 q -8 8 -18 2 q -10 6 -18 -2 q -4 -2 4 -4" />
          <path d="M 76 18 q -4 -10 6 -12 q 10 -4 18 2 q 8 -2 12 6 q 4 8 -4 12 q -10 6 -20 0 q -10 4 -16 -4 q -2 -2 4 -4" />
          <path d="M 146 20 q -4 -8 4 -10 q 8 -4 14 2 q 8 -2 10 6 q 2 8 -6 10 q -8 4 -16 -2 q -8 2 -10 -4 q 0 -2 4 -2" />
        </g>
        <path d={scribbleLine(6, 120, 194, 0.8, 12)} {...pen} />
        <g {...pen} transform="translate(96,98)">
          <circle cx="0" cy="0" r="2.2" />
          <path d="M -2 2 Q 0 4 2 2 Q 3 8 2 14 Q 0 15 -2 14 Q -3 8 -2 2 Z" />
          <line x1="-1" y1="14" x2="-1.5" y2="20" />
          <line x1="1" y1="14" x2="1.5" y2="20" />
        </g>
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    morning: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        {highlight && (
          <ellipse cx="100" cy="70" rx="40" ry="34" fill={yellow} opacity="0.45" filter="url(#inkWobble)" />
        )}
        <g {...pen}>
          <circle cx="100" cy="68" r="20" />
          <circle cx="100" cy="68" r="20.6" opacity="0.5" />
        </g>
        <g {...penMid}>
          {Array.from({ length: 10 }).map((_, i) => {
            const a = (i / 10) * Math.PI * 2;
            return <line key={i} x1={100 + Math.cos(a) * 24} y1={68 + Math.sin(a) * 24}
                         x2={100 + Math.cos(a) * 28} y2={68 + Math.sin(a) * 28} />;
          })}
        </g>
        <path d={scribbleLine(4, 96, 196, 0.9, 10)} {...pen} />
        <path d={scribbleLine(4, 110, 196, 0.7, 14)} {...pen} />
        {worked && (
          <g {...hatchLine}>
            {[100,104,108,112,116,120].map((y,i) => (
              <path key={i} d={scribbleLine(4, y, 196, 0.5, 14)} opacity={0.3 - i*0.03} />
            ))}
          </g>
        )}
        <g {...penMid}>
          <path d="M 38 36 q 3 -3 5 0 q 2 -3 4 0" />
          <path d="M 54 28 q 2 -2 4 0 q 1 -2 3 0" />
          <path d="M 70 34 q 2 -2 4 0 q 1 -2 3 0" />
        </g>
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    midnight: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g {...pen}>
          <path d="M 46 26 a 12 12 0 1 0 0 20 a 9 9 0 1 1 0 -20 z" />
        </g>
        <g {...pen} strokeWidth="0.9">
          {[[24,54],[88,22],[122,16],[150,44],[168,22],[110,62],[30,82],[180,80],[95,96],[74,38]].map(([x,y],i) => (
            <g key={i}>
              <line x1={x-2.5} y1={y} x2={x+2.5} y2={y} />
              <line x1={x} y1={y-2.5} x2={x} y2={y+2.5} />
              <line x1={x-1.7} y1={y-1.7} x2={x+1.7} y2={y+1.7} />
              <line x1={x-1.7} y1={y+1.7} x2={x+1.7} y2={y-1.7} />
            </g>
          ))}
        </g>
        <g {...pen} transform="translate(130,92)">
          <path d="M 0 24 L 0 8 L 22 -6 L 44 8 L 44 24 Z" />
          <path d="M 0 8 L 22 -6 L 44 8" />
          <rect x="10" y="10" width="8" height="10" />
          <rect x="26" y="10" width="8" height="10" />
          {worked && (
            <g {...hatchLine}>
              {[11,13,15,17].map((y,j) => <line key={j} x1="11" y1={y} x2="17" y2={y} />)}
              {[11,13,15,17].map((y,j) => <line key={`b${j}`} x1="27" y1={y} x2="33" y2={y} />)}
            </g>
          )}
          {highlight && <rect x="10" y="10" width="8" height="10" fill={yellow} opacity="0.7" filter="url(#inkWobble)" />}
          {highlight && <rect x="26" y="10" width="8" height="10" fill={yellow} opacity="0.7" filter="url(#inkWobble)" />}
        </g>
        <path d={scribbleLine(6, 122, 194, 0.6, 12)} {...pen} />
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    window: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g {...pen}>
          <path d="M 28 16 L 28 122 L 172 122 L 172 16 Z" />
          <path d="M 100 16 L 100 122" />
          <path d="M 28 68 L 172 68" />
        </g>
        <g {...pen}>
          <circle cx="60" cy="40" r="10" />
        </g>
        {highlight && <rect x="28" y="16" width="72" height="52" fill={yellow} opacity="0.35" filter="url(#inkWobble)" />}
        <g {...pen} strokeWidth="0.7">
          {[[136,32],[148,50],[128,56],[156,26],[140,90]].map(([x,y],i) => (
            <g key={i}>
              <line x1={x-1.6} y1={y} x2={x+1.6} y2={y} />
              <line x1={x} y1={y-1.6} x2={x} y2={y+1.6} />
            </g>
          ))}
        </g>
        <g {...pen} transform="translate(114,86)">
          <circle cx="0" cy="0" r="3" />
          <path d="M -3 3 Q 0 6 3 3 Q 5 14 3 28 Q 0 30 -3 28 Q -5 14 -3 3 Z" />
        </g>
        <path d={scribbleLine(18, 124, 182, 0.4, 12)} {...pen} />
        <path d={scribbleLine(18, 130, 182, 0.4, 12)} {...pen} />
        {panelNum != null && <text x="180" y="16" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    cover: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g {...pen}>
          <circle cx="62" cy="52" r="22" />
          <circle cx="62" cy="52" r="22.6" opacity="0.5" />
        </g>
        <g {...penMid}>
          {Array.from({ length: 14 }).map((_, i) => {
            const a = (i / 14) * Math.PI * 2;
            return <line key={i} x1={62 + Math.cos(a) * 26} y1={52 + Math.sin(a) * 26}
                         x2={62 + Math.cos(a) * 30} y2={52 + Math.sin(a) * 30} />;
          })}
        </g>
        <path d={scribbleLine(4, 92, 196, 0.9, 10)} {...pen} />
        <path d={scribbleLine(4, 108, 196, 0.7, 14)} {...pen} />
        <g {...penLight}>
          <path d="M 4 4 L 12 4 M 4 4 L 4 12" />
          <path d="M 196 4 L 188 4 M 196 4 L 196 12" />
          <path d="M 4 136 L 12 136 M 4 136 L 4 128" />
          <path d="M 196 136 L 188 136 M 196 136 L 196 128" />
        </g>
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    text: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <ScribbleText x={20} y={32} width={160} lines={7} gap={11} />
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    textWithSketch: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <g {...pen} transform="translate(20,40)">
          <path d="M 0 40 Q 10 38 20 40 T 40 40" />
          <path d="M 6 36 q 1 -6 3 0" />
          <path d="M 14 34 q 1 -10 3 0" />
          <path d="M 28 35 q 1 -8 3 0" />
          <g transform="translate(32,20)">
            <circle cx="0" cy="0" r="2" />
            <line x1="0" y1="2" x2="0" y2="12" />
            <line x1="0" y1="6" x2="-4" y2="10" />
            <line x1="0" y1="6" x2="4" y2="10" />
            <line x1="0" y1="12" x2="-3" y2="18" />
            <line x1="0" y1="12" x2="3" y2="18" />
          </g>
        </g>
        <g {...penMid}>
          {[40, 54, 68, 82, 96].map((y, i) => (
            <path key={i} d={scribbleLine(90, y, 184, 0.7, 6)} />
          ))}
        </g>
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),

    blank: (
      <svg viewBox="0 0 200 140" preserveAspectRatio="xMidYMid slice">
        <path d={scribbleLine(40, 70, 160, 0.5, 20)} {...penLight} strokeDasharray="2 4" />
        {panelNum != null && <text x="182" y="18" fontFamily="Caveat, cursive" fontSize="14" fill={ink}>{panelNum}</text>}
      </svg>
    ),
  };

  return <div className="scene">{scenes[name] || scenes.blank}</div>;
};

// Spread: a two-page composition. Pages can be image-first or text-first.
// Each `page` prop can be:
//   { scene: 'dusk', title: 'The Quiet Hour', caption: '...' }  — art page
//   { text: 'Nana says...' }  — text page
//   { label: '...' }  — just a corner label
const Spread = ({ mood = 'morning', label, text, left, right, scene, className = '',
                  worked = false, highlight = false, panelNums }) => {
  // Back-compat: if old props (label/text/scene) passed, build left/right.
  const dark = mood === 'midnight';
  const _left = left || (scene ? { scene, label } : { label });
  const _right = right || (text ? { text } : {});
  const [ln, rn] = panelNums || [];
  return (
    <div className={`spread mood-${mood} ${className}`}>
      <div className="half">
        {_left.scene && <Scene name={_left.scene} dark={dark} worked={worked} highlight={highlight} panelNum={ln} />}
        {_left.label && <span className="spread-label">{_left.label}</span>}
        {_left.title && (
          <h4 className="spread-title">
            {_left.drop && <span className="drop">{_left.drop}</span>}
            {_left.title}
          </h4>
        )}
        {_left.caption && <div className="spread-caption">{_left.caption}</div>}
        {_left.text && <p className="spread-text">{_left.text}</p>}
      </div>
      <div className="spine"></div>
      <div className="half">
        {_right.scene && <Scene name={_right.scene} dark={dark} worked={worked} highlight={highlight} panelNum={rn} />}
        {_right.label && <span className="spread-label">{_right.label}</span>}
        {_right.title && (
          <h4 className="spread-title">
            {_right.drop && <span className="drop">{_right.drop}</span>}
            {_right.title}
          </h4>
        )}
        {_right.caption && <div className="spread-caption">{_right.caption}</div>}
        {_right.text && <p className="spread-text">{_right.text}</p>}
      </div>
    </div>
  );
};

// ─── Screen: Story / Storyboard grid ─────────────────────────────
const StoryboardScreen = () => {
  const spreads = [
    { label: 'Cover', mood: 'cream', left: { scene: 'cover' }, right: { title: 'The Quiet Hour', drop: 'T', caption: 'a picture book' } },
    { label: 'pp. 2–3', mood: 'morning', left: { scene: 'morning' }, right: { text: 'The sun is almost gone.' } },
    { label: 'pp. 4–5', mood: 'dusk', left: { scene: 'dusk' }, right: { text: 'Nana says it is the quiet hour.' } },
    { label: 'pp. 6–7', mood: 'forest', left: { scene: 'forest' }, right: { text: 'The trees are breathing slowly.' } },
    { label: 'pp. 8–9', mood: 'dusk', left: { text: 'A fox stops. A bird folds. The world leans in.' }, right: { scene: 'dusk' } },
    { label: 'pp. 10–11', mood: 'midnight', left: { scene: 'midnight' }, right: { text: 'First a pink, then a purple, then a blue.' } },
    { label: 'pp. 12–13', mood: 'midnight', left: { scene: 'window' }, right: { scene: 'midnight' } },
    { label: 'pp. 14–15', mood: 'midnight', left: { scene: 'window' }, right: { text: 'The world is tucking itself in.' } },
    { label: 'pp. 16–17', mood: 'midnight', left: { text: 'Goodnight, says Nana.\nGoodnight, says the child.' }, right: { scene: 'midnight' } },
    { label: 'End', mood: 'cream', left: {}, right: { title: 'for nana', drop: 'f', caption: '— the end —' } },
  ];
  return (
    <div className="screen-frame" style={{ width: '100%' }}>
      <div className="screen-bar">
        <div className="dot-trio"><span></span><span></span><span></span></div>
        <span className="title">storyfolio · the quiet hour · storyboard</span>
      </div>
      <div style={{ display: 'flex', minHeight: 560 }}>
        {/* Sidebar */}
        <aside style={{
          width: 68, borderRight: '1px solid var(--cream-300)',
          background: 'var(--cream-200)', padding: '18px 0',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
        }}>
          <div style={{ width: 42, height: 22, borderRadius: 8, color: 'rgba(74,69,64,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, marginBottom: 8 }}>←</div>
          <p style={{ fontSize: 9, color: 'rgba(74,69,64,0.55)', textAlign: 'center', margin: '0 0 16px', lineHeight: 1.2, width: 48 }}>The Quiet Hour</p>
          {[
            { icon: '✦', label: 'Story', active: true },
            { icon: '✏', label: 'Draw' },
            { icon: '◎', label: 'Publish' },
            { icon: '✧', label: 'Partner' },
          ].map((n) => (
            <button key={n.label} style={{
              width: 48, height: 48, borderRadius: 12, border: 0,
              background: n.active ? 'var(--cream-100)' : 'transparent',
              color: n.active ? 'var(--ochre-500)' : 'rgba(74,69,64,0.4)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2,
              boxShadow: n.active ? 'var(--shadow-soft)' : 'none',
              cursor: 'pointer', fontFamily: 'inherit',
            }}>
              <span style={{ fontSize: 15 }}>{n.icon}</span>
              <span style={{ fontSize: 9, fontWeight: 500 }}>{n.label}</span>
            </button>
          ))}
        </aside>
        {/* Main */}
        <main style={{ flex: 1, padding: '22px 28px', overflow: 'hidden' }}>
          {/* Synopsis pill */}
          <div style={{ background: 'var(--cream-200)', border: '1px solid var(--cream-300)', borderRadius: 14, padding: '10px 16px', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: 'var(--ochre-500)' }}>✦</span>
            <span style={{ fontFamily: 'Lora, serif', fontSize: 13, color: 'var(--ink-700)' }}>Synopsis</span>
            <span style={{ fontSize: 12, color: 'rgba(74,69,64,0.55)' }}>A grandmother teaches a child to notice the moment between day and night…</span>
            <span style={{ marginLeft: 'auto', fontSize: 11, color: 'rgba(74,69,64,0.35)' }}>▾</span>
          </div>
          {/* Story Arc pill */}
          <div style={{ background: 'var(--cream-200)', border: '1px solid var(--cream-300)', borderRadius: 14, padding: '10px 16px', marginBottom: 22, display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{ color: 'var(--ochre-500)' }}>✦</span>
            <span style={{ fontFamily: 'Lora, serif', fontSize: 13, color: 'var(--ink-700)' }}>Story Arc</span>
            <span style={{ fontSize: 11, color: 'rgba(74,69,64,0.5)' }}>8 / 10 beats</span>
            <span style={{ marginLeft: 'auto', fontSize: 11, color: 'rgba(74,69,64,0.35)' }}>▾</span>
          </div>

          {/* Title + controls */}
          <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 16 }}>
            <h3 style={{ fontFamily: 'Lora, serif', fontSize: 20, margin: 0, color: 'var(--ink-700)' }}>The Quiet Hour</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span style={{ fontSize: 11, color: 'rgba(74,69,64,0.4)' }}>7 / 10 spreads</span>
              <button style={{ fontSize: 11, border: '1px solid var(--cream-300)', background: 'transparent', padding: '6px 10px', borderRadius: 10, color: 'rgba(74,69,64,0.55)', cursor: 'pointer', fontFamily: 'inherit' }}>▶ Read</button>
            </div>
          </div>

          {/* Spread grid — thumbnails show scene-only (text illegible at this scale) */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14 }}>
            {spreads.map((s, i) => {
              // Text pages become scribbled manuscript lines. Image pages keep scene.
              // Cover has no opposite page (title area) — use 'blank'.
              const isCover = i === 0;
              const isEnd = i === spreads.length - 1;
              const leftScene = s.left?.scene || (s.left?.text ? 'text' : 'blank');
              const rightScene = s.right?.scene || (s.right?.text ? 'text' : (isCover || isEnd ? 'blank' : 'text'));
              const active = i === 2;
              // Real book-style numbering: cover unnumbered, then 2..n.
              const leftNum = isCover || isEnd ? null : i * 2;
              const rightNum = isCover || isEnd ? null : i * 2 + 1;
              return (
                <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  <div style={{ borderRadius: 6, overflow: 'hidden', border: '1px solid var(--cream-300)', boxShadow: active ? '0 0 0 2px var(--ochre-400)' : 'none' }}>
                    <Spread mood={s.mood}
                            left={{ scene: leftScene }}
                            right={{ scene: rightScene }}
                            worked={active}
                            highlight={active}
                            panelNums={[leftNum, rightNum]} />
                  </div>
                  <span style={{ fontSize: 9, color: 'rgba(74,69,64,0.55)', textAlign: 'center' }}>{s.label}</span>
                </div>
              );
            })}
          </div>
        </main>
      </div>
    </div>
  );
};

// ─── Screen: Spread Edit Panel ───────────────────────────────────
const SpreadEditScreen = () => (
  <div className="screen-frame" style={{ width: '100%' }}>
    <div className="screen-bar">
      <div className="dot-trio"><span></span><span></span><span></span></div>
      <span className="title">storyfolio · spread pp. 4–5</span>
    </div>
    <div style={{ padding: '10px 16px', borderBottom: '1px solid var(--cream-300)', display: 'flex', alignItems: 'center', gap: 12, background: 'var(--cream-50)' }}>
      <span style={{ fontSize: 11, color: 'rgba(74,69,64,0.5)' }}>← Storyboard</span>
      <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--ochre-600)', background: 'rgba(200,145,58,0.1)', padding: '2px 10px', borderRadius: 999 }}>pp. 4–5</span>
      <span style={{ fontSize: 10, color: 'rgba(74,69,64,0.35)' }}>spread 3 of 10</span>
      <span style={{ marginLeft: 'auto', fontSize: 10, border: '1px solid var(--cream-300)', padding: '3px 10px', borderRadius: 999, color: 'rgba(74,69,64,0.5)' }}>○ Lock</span>
    </div>
    <div style={{ padding: '28px 40px', maxHeight: 600, overflow: 'hidden' }}>
      <div style={{ maxWidth: 560, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Beat */}
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 6 }}>Story Beat</div>
          <div style={{ background: 'var(--cream-50)', border: '1px solid var(--cream-300)', borderRadius: 12, padding: '10px 14px', fontSize: 13, color: 'var(--ink-700)', fontFamily: 'DM Sans' }}>
            Nana and the child step onto the porch as the sky begins to change.
          </div>
        </div>
        {/* Sketch */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)' }}>Sketch</span>
            <span style={{ fontSize: 10, color: 'var(--ochre-600)' }}>+ Add version</span>
          </div>
          <div style={{ borderRadius: 12, overflow: 'hidden', border: '1px solid var(--cream-300)' }}>
            <Spread mood="dusk" left={{ scene: 'dusk' }} right={{ text: 'Nana says it is the quiet hour.' }} worked highlight panelNums={[4, 5]} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, background: 'rgba(44,40,37,0.08)', color: 'rgba(74,69,64,0.7)', padding: '2px 6px', borderRadius: 4 }}>v3</span>
            <span style={{ fontSize: 10, color: 'rgba(74,69,64,0.5)', fontStyle: 'italic' }}>refined — warmer porch light</span>
          </div>
        </div>
        {/* Manuscript */}
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 6 }}>Manuscript</div>
          <div style={{ background: 'var(--cream-50)', border: '1px solid var(--cream-300)', borderRadius: 12, padding: '14px 16px', fontFamily: 'Lora, serif', fontSize: 16, color: 'var(--ink-700)', lineHeight: 1.55 }}>
            Nana says it is the quiet hour.<br/>
            Not day. Not night. Something in between.
          </div>
        </div>
        {/* Art notes */}
        <div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 10 }}>Art Notes</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { l: 'Characters', v: 'Nana (warm cardigan, silver hair in a low bun) and Wren (7yrs, barefoot)' },
              { l: 'Scene', v: 'Front porch, late summer dusk — crickets starting, last pink in the sky' },
              { l: 'Design', v: 'Low contrast, rose into violet wash. Keep faces softly lit.' },
            ].map((f) => (
              <div key={f.l}>
                <div style={{ fontSize: 10, color: 'rgba(74,69,64,0.4)', marginBottom: 3 }}>{f.l}</div>
                <div style={{ background: 'var(--cream-50)', border: '1px solid var(--cream-300)', borderRadius: 10, padding: '8px 12px', fontSize: 13, color: 'var(--ink-700)', lineHeight: 1.4 }}>
                  {f.v}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  </div>
);

// ─── Screen: Creative Partner chat ───────────────────────────────
const PartnerScreen = () => (
  <div className="screen-frame" style={{ width: '100%' }}>
    <div className="screen-bar">
      <div className="dot-trio"><span></span><span></span><span></span></div>
      <span className="title">storyfolio · creative partner</span>
    </div>
    <div style={{ padding: '14px 22px', borderBottom: '1px solid var(--cream-300)', display: 'flex', alignItems: 'center', gap: 12 }}>
      <span style={{ color: 'var(--ochre-500)', fontSize: 16 }}>✧</span>
      <div>
        <div style={{ fontFamily: 'Lora, serif', fontSize: 15, color: 'var(--ink-700)' }}>Creative Partner</div>
        <div style={{ fontSize: 11, color: 'rgba(74,69,64,0.5)' }}>The Quiet Hour · private to this project</div>
      </div>
      <div style={{ marginLeft: 'auto', display: 'flex', gap: 10, fontSize: 11, color: 'rgba(74,69,64,0.5)' }}>
        <span>Export</span><span>Clear</span>
      </div>
    </div>
    <div style={{ padding: '28px 40px 20px', display: 'flex', flexDirection: 'column', gap: 18, maxHeight: 520, overflow: 'hidden' }}>
      {/* User msg */}
      <div style={{ alignSelf: 'flex-end', maxWidth: '70%', background: 'rgba(200,145,58,0.12)', borderRadius: 18, padding: '12px 16px', fontSize: 14, color: 'var(--ink-700)', lineHeight: 1.5 }}>
        Reading my storyboard end to end — is the middle sagging? The dusk sequence feels repetitive to me.
      </div>
      {/* Shared storyboard pill */}
      <div style={{ alignSelf: 'flex-end', fontSize: 11, fontFamily: 'JetBrains Mono, monospace', color: 'var(--ochre-600)', background: 'rgba(200,145,58,0.08)', border: '1px solid rgba(200,145,58,0.3)', borderRadius: 999, padding: '4px 12px' }}>
        ✦ shared storyboard · 10 spreads attached
      </div>
      {/* Assistant msg */}
      <div style={{ maxWidth: '78%', background: '#fff', border: '1px solid var(--cream-300)', borderRadius: 18, padding: '14px 18px', fontSize: 14, color: 'var(--ink-500)', lineHeight: 1.6 }}>
        <p style={{ margin: '0 0 10px' }}>Honest read: the dusk sequence isn't sagging — it's <em>lingering</em>, which is the right instinct for a book about noticing. But you're repeating the same <strong>wide-shot porch</strong> in pp. 6–7 and pp. 8–9. That's where it flattens.</p>
        <p style={{ margin: '0 0 10px' }}>Consider pulling the camera in close on pp. 6–7 — Wren's hands on the railing, or the fireflies arriving at knee-height. Let pp. 8–9 keep the wide.</p>
        <p style={{ margin: 0 }}>Strongest spread: <strong>pp. 10–11</strong>. The "first a pink, then a purple, then a blue" text is doing so much work — the art can breathe. Don't over-illustrate it.</p>
      </div>
      {/* Composer */}
      <div style={{ marginTop: 8, border: '1px solid var(--cream-300)', borderRadius: 14, background: 'var(--cream-50)', padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ color: 'rgba(74,69,64,0.3)', fontSize: 14 }}>↑</span>
        <span style={{ flex: 1, fontSize: 13, color: 'rgba(74,69,64,0.4)' }}>Continue the conversation…</span>
        <button style={{ background: 'var(--ochre-500)', color: '#fff', border: 0, borderRadius: 10, padding: '6px 14px', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>→</button>
      </div>
    </div>
  </div>
);

// ─── Screen: Publish ─────────────────────────────────────────────
const PublishScreen = () => (
  <div className="screen-frame" style={{ width: '100%' }}>
    <div className="screen-bar">
      <div className="dot-trio"><span></span><span></span><span></span></div>
      <span className="title">storyfolio · publish</span>
    </div>
    <div style={{ padding: '32px 40px', maxHeight: 560, overflow: 'hidden' }}>
      <h3 style={{ fontFamily: 'Lora, serif', fontSize: 22, color: 'var(--ink-700)', margin: '0 0 4px' }}>Publish</h3>
      <p style={{ margin: '0 0 24px', fontSize: 13, color: 'rgba(74,69,64,0.6)' }}>Export submission-ready documents from your project.</p>

      {/* Statement card */}
      <div style={{ background: 'var(--cream-200)', border: '1px solid var(--cream-300)', borderRadius: 16, overflow: 'hidden', marginBottom: 22 }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--cream-300)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <div style={{ fontFamily: 'Lora, serif', fontSize: 14, color: 'var(--ink-700)' }}>Statement 1-Pager</div>
            <div style={{ fontSize: 12, color: 'rgba(74,69,64,0.55)', marginTop: 2 }}>Logline, POV, comparables — one page for agents.</div>
          </div>
          <button style={{ background: 'var(--ochre-500)', color: '#fff', border: 0, borderRadius: 10, padding: '6px 12px', fontSize: 12, fontFamily: 'inherit', cursor: 'pointer' }}>Preview & Export</button>
        </div>
        <div style={{ padding: '18px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          {[
            { l: 'Logline', v: 'A child learns from her grandmother to notice the small, in-between hour when the world changes.' },
            { l: 'POV', v: 'Written from the memory of my own summers with Ba — teaching me to see slowly.' },
          ].map((f) => (
            <div key={f.l}>
              <div style={{ fontSize: 11, color: 'rgba(74,69,64,0.55)', marginBottom: 4 }}>{f.l}</div>
              <div style={{ background: 'var(--cream-50)', border: '1px solid var(--cream-300)', borderRadius: 10, padding: '10px 12px', fontSize: 12, color: 'var(--ink-700)', lineHeight: 1.5 }}>{f.v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Deliverables */}
      <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 12 }}>Manuscript & Book Dummy</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
        {[
          { t: 'Book Dummy', d: 'Spreads with text placed and B&W sketches.' },
          { t: 'Manuscript 1', d: 'Paginated with art notes after each spread.' },
          { t: 'Manuscript 2', d: 'Clean plain text. One spread per section.' },
        ].map((c) => (
          <div key={c.t} style={{ background: 'var(--cream-50)', border: '1px solid var(--cream-300)', borderRadius: 14, padding: '16px 18px' }}>
            <div style={{ fontFamily: 'Lora, serif', fontSize: 14, color: 'var(--ink-700)', marginBottom: 4 }}>{c.t}</div>
            <div style={{ fontSize: 12, color: 'rgba(74,69,64,0.6)', lineHeight: 1.4, marginBottom: 10 }}>{c.d}</div>
            <div style={{ fontSize: 10, color: 'var(--moss-600)', marginBottom: 12 }}>✦ 7 locked spreads will be included</div>
            <button style={{ background: 'var(--ochre-500)', color: '#fff', border: 0, borderRadius: 10, padding: '5px 12px', fontSize: 11, fontFamily: 'inherit', cursor: 'pointer' }}>Preview & Export</button>
          </div>
        ))}
      </div>
    </div>
  </div>
);

// ─── Character portrait: real drawn sketch for the character card ───
const CharacterPortrait = ({ who = 'wren' }) => {
  const ink = 'rgba(32,28,24,0.92)';
  const inkMid = 'rgba(32,28,24,0.6)';
  const inkLight = 'rgba(32,28,24,0.32)';
  const black = 'rgba(18,14,12,0.95)';
  const skin = '#EFD3BD';
  const skinShade = '#D9B69A';
  const shirt = '#C98F53';
  const stripe = '#F3E3CD';
  const paper = '#F4EBDB';

  if (who === 'wren') {
    return (
      <svg viewBox="0 0 180 216" style={{ width: '100%', height: '100%', display: 'block' }}>
        <rect width="180" height="216" fill={paper} />
        <g stroke={inkLight} strokeWidth="0.4">
          <path d="M 8 8 L 16 8 M 8 8 L 8 16" />
          <path d="M 172 8 L 164 8 M 172 8 L 172 16" />
          <path d="M 8 208 L 16 208 M 8 208 L 8 200" />
          <path d="M 172 208 L 164 208 M 172 208 L 172 200" />
        </g>
        <text x="12" y="28" fontFamily="Caveat, cursive" fontSize="11" fill={inkMid}>Wren · 7 yrs</text>
        <text x="12" y="204" fontFamily="Caveat, cursive" fontSize="10" fill={inkMid}>~42" tall · always barefoot</text>

        <path d="M 78 128 L 78 144 L 102 144 L 102 128" fill={skin} stroke={ink} strokeWidth="1.1" filter="url(#inkWobble)" />
        <path d="M 78 140 Q 90 144 102 140 L 102 144 L 78 144 Z" fill={skinShade} opacity="0.7" filter="url(#inkWobble)" />

        <path d="M 50 178 Q 54 150 78 144 Q 90 148 102 144 Q 126 150 130 178 L 134 200 L 46 200 Z" fill={shirt} stroke={ink} strokeWidth="1.2" filter="url(#inkWobble)" />
        <g fill={stripe} opacity="0.9" filter="url(#inkWobble)">
          <path d="M 50 170 Q 90 166 130 170 L 132 178 Q 90 174 50 178 Z" />
          <path d="M 48 190 Q 90 186 132 190 L 134 198 Q 90 194 46 198 Z" />
        </g>

        <path d="M 56 88 Q 54 62 72 52 Q 90 46 108 52 Q 126 62 124 88 Q 124 108 116 120 Q 106 130 90 130 Q 74 130 64 120 Q 56 108 56 88 Z" fill={skin} stroke={ink} strokeWidth="1.3" filter="url(#inkWobble)" />
        <path d="M 62 100 Q 66 116 78 122" fill="none" stroke={skinShade} strokeWidth="3" opacity="0.55" filter="url(#inkWobble)" />
        <path d="M 118 100 Q 114 116 102 122" fill="none" stroke={skinShade} strokeWidth="3" opacity="0.55" filter="url(#inkWobble)" />

        <g fill={black} stroke={ink} strokeWidth="1" filter="url(#inkWobble)">
          <path d="M 54 84 Q 48 68 58 56 Q 60 40 76 40 Q 90 32 108 40 Q 124 42 128 58 Q 132 70 128 84 Q 130 72 122 66 Q 110 60 96 62 Q 80 60 70 68 Q 58 74 56 86 Z" />
          <path d="M 54 88 q -6 10 -2 22 q 2 -8 6 -12" />
          <path d="M 128 88 q 6 10 2 22 q -2 -8 -6 -12" />
          <path d="M 68 62 L 74 78 L 80 64 L 86 78 L 92 62 L 98 78 L 104 62 L 110 78 L 116 62" fill="none" stroke={ink} strokeWidth="1" />
        </g>

        <path d="M 68 84 Q 74 82 80 84" stroke={ink} strokeWidth="1.2" fill="none" filter="url(#inkWobble)" />
        <path d="M 100 84 Q 106 82 112 84" stroke={ink} strokeWidth="1.2" fill="none" filter="url(#inkWobble)" />

        <g filter="url(#inkWobble)">
          <ellipse cx="74" cy="92" rx="3.6" ry="4.2" fill={black} />
          <ellipse cx="106" cy="92" rx="3.6" ry="4.2" fill={black} />
          <circle cx="75.2" cy="90.5" r="0.9" fill="#fff" />
          <circle cx="107.2" cy="90.5" r="0.9" fill="#fff" />
          <path d="M 69 92 Q 74 96 79 92" stroke={ink} strokeWidth="0.9" fill="none" />
          <path d="M 101 92 Q 106 96 111 92" stroke={ink} strokeWidth="0.9" fill="none" />
        </g>

        <path d="M 88 104 Q 90 108 92 106" stroke={ink} strokeWidth="0.9" fill="none" filter="url(#inkWobble)" />

        <path d="M 82 118 Q 90 122 98 118" stroke={ink} strokeWidth="1.1" fill="none" filter="url(#inkWobble)" />

        <g fill={ink} filter="url(#inkWobble)">
          <circle cx="82" cy="106" r="0.6" />
          <circle cx="86" cy="109" r="0.5" />
          <circle cx="94" cy="108" r="0.6" />
          <circle cx="98" cy="106" r="0.5" />
          <circle cx="72" cy="102" r="0.5" />
          <circle cx="110" cy="102" r="0.5" />
        </g>

        <path d="M 54 96 Q 48 100 54 108" stroke={ink} strokeWidth="1" fill={skin} filter="url(#inkWobble)" />
        <path d="M 126 96 Q 132 100 126 108" stroke={ink} strokeWidth="1" fill={skin} filter="url(#inkWobble)" />

        <g stroke={inkMid} strokeWidth="0.5" fill="none">
          <path d="M 138 50 L 128 62" />
          <path d="M 128 62 l 3 -1 l -1 3" fill={inkMid} />
        </g>
        <text x="138" y="48" fontFamily="Caveat, cursive" fontSize="9" fill={inkMid}>messy bob</text>

        <g stroke={inkMid} strokeWidth="0.5" fill="none">
          <path d="M 42 170 L 52 174" />
          <path d="M 52 174 l -3 0 l 1 -2" fill={inkMid} />
        </g>
        <text x="12" y="166" fontFamily="Caveat, cursive" fontSize="9" fill={inkMid}>stripes ✓</text>
      </svg>
    );
  }

  // Nana — grandmother portrait
  const nanaHair = '#E8DFC8';
  const nanaCardigan = '#A67B4F';
  const nanaShirt = '#E9D8B8';

  return (
    <svg viewBox="0 0 180 216" style={{ width: '100%', height: '100%', display: 'block' }}>
      <rect width="180" height="216" fill={paper} />
      <g stroke={inkLight} strokeWidth="0.4">
        <path d="M 8 8 L 16 8 M 8 8 L 8 16" />
        <path d="M 172 8 L 164 8 M 172 8 L 172 16" />
        <path d="M 8 208 L 16 208 M 8 208 L 8 200" />
        <path d="M 172 208 L 164 208 M 172 208 L 172 200" />
      </g>
      <text x="12" y="28" fontFamily="Caveat, cursive" fontSize="11" fill={inkMid}>Nana · grandmother</text>
      <text x="12" y="204" fontFamily="Caveat, cursive" fontSize="10" fill={inkMid}>warm cardigan · always knitting</text>

      <path d="M 80 128 L 80 142 L 100 142 L 100 128" fill={skin} stroke={ink} strokeWidth="1.1" filter="url(#inkWobble)" />

      <path d="M 44 180 Q 48 152 76 144 Q 90 148 104 144 Q 132 152 136 180 L 140 202 L 40 202 Z" fill={nanaCardigan} stroke={ink} strokeWidth="1.2" filter="url(#inkWobble)" />
      <path d="M 78 144 Q 84 170 82 202 L 98 202 Q 96 170 102 144 Q 90 148 78 144 Z" fill={nanaShirt} stroke={ink} strokeWidth="0.9" filter="url(#inkWobble)" />
      <g stroke={ink} strokeWidth="0.3" opacity="0.4" filter="url(#inkWobble)">
        {Array.from({ length: 10 }).map((_, i) => (
          <path key={'k1-' + i} d={'M ' + (46 + i * 10) + ' 150 L ' + (48 + i * 10) + ' 200'} />
        ))}
        {Array.from({ length: 6 }).map((_, i) => (
          <path key={'k2-' + i} d={'M 44 ' + (160 + i * 8) + ' Q 90 ' + (158 + i * 8) + ' 136 ' + (160 + i * 8)} />
        ))}
      </g>
      <g fill={black} stroke={ink} strokeWidth="0.4">
        <circle cx="90" cy="160" r="1.6" />
        <circle cx="90" cy="174" r="1.6" />
        <circle cx="90" cy="188" r="1.6" />
      </g>

      <path d="M 54 92 Q 52 66 70 56 Q 90 50 110 56 Q 128 66 126 92 Q 126 110 118 122 Q 108 132 90 132 Q 72 132 62 122 Q 54 110 54 92 Z" fill={skin} stroke={ink} strokeWidth="1.3" filter="url(#inkWobble)" />

      <g fill={nanaHair} stroke={ink} strokeWidth="1" filter="url(#inkWobble)">
        <ellipse cx="90" cy="40" rx="18" ry="10" />
        <path d="M 56 88 Q 50 68 62 58 Q 76 48 90 48 Q 104 48 118 58 Q 130 68 124 88 Q 122 76 112 70 Q 100 68 90 72 Q 80 68 68 70 Q 58 76 56 88 Z" />
      </g>
      <g stroke={ink} strokeWidth="0.6" fill="none" filter="url(#inkWobble)">
        <path d="M 58 82 q -4 8 -2 16" />
        <path d="M 122 82 q 4 8 2 16" />
        <path d="M 76 52 q 0 -4 4 -6" />
        <path d="M 104 52 q 0 -4 -4 -6" />
      </g>
      <g stroke={ink} strokeWidth="0.35" opacity="0.5" filter="url(#inkWobble)">
        <path d="M 74 38 Q 90 44 106 38" />
        <path d="M 76 34 Q 90 40 104 34" />
      </g>

      <g stroke={ink} strokeWidth="1" fill="rgba(255,255,255,0.2)" filter="url(#inkWobble)">
        <circle cx="74" cy="94" r="8" />
        <circle cx="106" cy="94" r="8" />
        <line x1="82" y1="94" x2="98" y2="94" />
        <path d="M 66 94 Q 58 94 56 98" fill="none" />
        <path d="M 114 94 Q 122 94 124 98" fill="none" />
      </g>

      <g filter="url(#inkWobble)">
        <ellipse cx="74" cy="95" rx="2" ry="1.6" fill={black} />
        <ellipse cx="106" cy="95" rx="2" ry="1.6" fill={black} />
        <circle cx="74.5" cy="94.4" r="0.5" fill="#fff" />
        <circle cx="106.5" cy="94.4" r="0.5" fill="#fff" />
      </g>
      <g stroke={ink} strokeWidth="0.5" fill="none" filter="url(#inkWobble)">
        <path d="M 64 92 l -3 -2" />
        <path d="M 64 95 l -3 0" />
        <path d="M 64 98 l -3 2" />
        <path d="M 116 92 l 3 -2" />
        <path d="M 116 95 l 3 0" />
        <path d="M 116 98 l 3 2" />
      </g>

      <path d="M 88 104 Q 90 112 94 110" stroke={ink} strokeWidth="0.9" fill="none" filter="url(#inkWobble)" />

      <path d="M 80 120 Q 90 126 100 120" stroke={ink} strokeWidth="1.1" fill="none" filter="url(#inkWobble)" />
      <path d="M 80 120 q 2 -2 0 -4" stroke={ink} strokeWidth="0.7" fill="none" />
      <path d="M 100 120 q -2 -2 0 -4" stroke={ink} strokeWidth="0.7" fill="none" />

      <ellipse cx="66" cy="108" rx="6" ry="3" fill="#E5A67C" opacity="0.45" filter="url(#inkWobble)" />
      <ellipse cx="114" cy="108" rx="6" ry="3" fill="#E5A67C" opacity="0.45" filter="url(#inkWobble)" />

      <circle cx="54" cy="104" r="1.2" fill="#F4EBDB" stroke={ink} strokeWidth="0.5" />
      <circle cx="126" cy="104" r="1.2" fill="#F4EBDB" stroke={ink} strokeWidth="0.5" />

      <path d="M 52 98 Q 46 102 52 110" stroke={ink} strokeWidth="1" fill={skin} filter="url(#inkWobble)" />
      <path d="M 128 98 Q 134 102 128 110" stroke={ink} strokeWidth="1" fill={skin} filter="url(#inkWobble)" />

      <g stroke={inkMid} strokeWidth="0.5" fill="none">
        <path d="M 138 90 L 126 96" />
        <path d="M 126 96 l 3 0 l -1 -2" fill={inkMid} />
      </g>
      <text x="138" y="88" fontFamily="Caveat, cursive" fontSize="9" fill={inkMid}>round specs</text>
      <g stroke={inkMid} strokeWidth="0.5" fill="none">
        <path d="M 42 162 L 52 164" />
        <path d="M 52 164 l -3 0 l 1 -2" fill={inkMid} />
      </g>
      <text x="12" y="158" fontFamily="Caveat, cursive" fontSize="9" fill={inkMid}>knit texture</text>
    </svg>
  );
};

// ─── Small card: character reference ─────────────────────────────
const CharacterCard = () => (
  <div className="screen-frame" style={{ width: '100%' }}>
    <div className="screen-bar">
      <div className="dot-trio"><span></span><span></span><span></span></div>
      <span className="title">storyfolio · characters</span>
    </div>
    <div style={{ display: 'flex', minHeight: 420 }}>
      <aside style={{ width: 160, borderRight: '1px solid var(--cream-300)', background: 'var(--cream-200)', padding: '16px 0' }}>
        <div style={{ padding: '0 16px 10px', display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--cream-300)' }}>
          <span style={{ fontFamily: 'Lora, serif', fontSize: 12, color: 'var(--ink-700)' }}>Characters</span>
          <span style={{ width: 20, height: 20, borderRadius: 6, background: 'var(--ochre-500)', color: '#fff', fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>+</span>
        </div>
        {['Wren', "Nana's Grandmother", 'The cat, Pepper'].map((n, i) => (
          <div key={n} style={{ padding: '10px 16px', background: i === 1 ? 'var(--cream-100)' : 'transparent' }}>
            <div style={{ fontSize: 13, color: i === 1 ? 'var(--ochre-600)' : 'var(--ink-500)', fontWeight: i === 1 ? 500 : 400 }}>{n}</div>
            <div style={{ fontSize: 11, color: 'rgba(74,69,64,0.45)' }}>{['child, 7', 'grandmother', 'tabby cat'][i]}</div>
          </div>
        ))}
      </aside>
      <main style={{ flex: 1, padding: '24px 32px', display: 'flex', gap: 24 }}>
        <div style={{ width: 180 }}>
          <div style={{ aspectRatio: '5/6', borderRadius: 12, border: '1px solid var(--cream-300)', position: 'relative', overflow: 'hidden', boxShadow: 'var(--shadow-soft)' }}>
            <CharacterPortrait who="nana" />
            <span style={{ position: 'absolute', bottom: 8, left: 10, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'rgba(44,40,37,0.55)', background: 'rgba(244,235,219,0.85)', padding: '1px 5px', borderRadius: 3 }}>[ nana's grandmother · ref ]</span>
          </div>
          <div style={{ fontSize: 10, color: 'rgba(74,69,64,0.5)', marginTop: 6, textAlign: 'center', fontFamily: 'JetBrains Mono, monospace' }}>--cref 100 --sref …</div>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontFamily: 'Lora, serif', fontSize: 22, color: 'var(--ink-700)', marginBottom: 4 }}>Nana's Grandmother</div>
          <div style={{ fontSize: 12, color: 'rgba(74,69,64,0.55)', marginBottom: 18 }}>great-great-grandmother · keeper of the quiet hour</div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 8 }}>Personality</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 18 }}>
            {['patient', 'warm', 'unhurried', 'observant', 'wry'].map((t) => (
              <span key={t} style={{ fontSize: 11, border: '1px solid var(--cream-300)', padding: '3px 10px', borderRadius: 999, background: 'var(--cream-50)', color: 'var(--ink-500)' }}>{t}</span>
            ))}
          </div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 8 }}>Visual</div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 18 }}>
            {['silver bun', 'round glasses', 'warm cardigan', 'pearl earrings', 'soft slippers'].map((t) => (
              <span key={t} style={{ fontSize: 11, border: '1px solid var(--cream-300)', padding: '3px 10px', borderRadius: 999, background: 'var(--cream-50)', color: 'var(--ink-500)' }}>{t}</span>
            ))}
          </div>
          <div style={{ fontSize: 10, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'rgba(74,69,64,0.5)', marginBottom: 8 }}>Notes</div>
          <p style={{ fontSize: 13, color: 'var(--ink-500)', lineHeight: 1.55, margin: 0, fontFamily: 'Lora, serif', fontStyle: 'italic' }}>
            Nana keeps her voice low and her hands busy. She doesn't explain the world to Wren — she points at it, and waits.
          </p>
        </div>
      </main>
    </div>
  </div>
);

Object.assign(window, { Spread, StoryboardScreen, SpreadEditScreen, PartnerScreen, PublishScreen, CharacterCard });
